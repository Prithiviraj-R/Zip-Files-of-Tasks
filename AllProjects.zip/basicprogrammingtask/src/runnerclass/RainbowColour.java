package runnerclass;
import java.util.*;

public enum RainbowColour 
{
		VIOLET,
		INDIGO,
		BLUE,
		GREEN,
		YELLOW,
		ORANGE,
		RED;
		public int getCode()
		{
			return ordinal()+1;
		}
		
	}