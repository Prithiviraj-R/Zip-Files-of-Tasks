module basicprogrammingtask {
}