package com.practice;

import java.util.*;

public class WordBreak
{
	
}
