package com.basicprogramming.inheritance;

abstract public class BirdAbstract 
{
     public void fly()
     {
    	 System.out.println("Bird can fly.");
     }
     public void speak()
     {
    	 System.out.println("Bird can speak");
     }
}
