package com.basicprogramming.inheritance;

abstract public class Bird
{
   public abstract void fly();
   public void speak()
   {
	   System.out.println("Bird can speak");
   }
}
