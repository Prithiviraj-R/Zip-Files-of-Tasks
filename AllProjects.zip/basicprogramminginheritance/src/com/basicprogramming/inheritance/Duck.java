package com.basicprogramming.inheritance;

public class Duck extends Bird
{
    public void fly()
    {
    	System.out.println("Duck can fly.");
    }
}
