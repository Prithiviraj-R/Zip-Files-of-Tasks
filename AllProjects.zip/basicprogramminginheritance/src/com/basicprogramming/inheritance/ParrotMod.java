package com.basicprogramming.inheritance;

public class ParrotMod extends BirdAbstract
{
  
  /*public void fly()
  {
	  System.out.println("Parrot can fly.");
  }
  public void speak()
  {
	  System.out.println("Parrot can speak.");
  }*/
  
}
