package pack;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import newexception.MistakeOccuredException;
import util.HelperUtil;

public class Utility 
{
	static Map<Integer,Customer> customerMap=new HashMap<>();
	static Map<Integer,Map<Long,AccountDetails>> accountMap=new HashMap<>();
	public static Map<Integer, Customer> addCustomer(int id,Customer object)
	{
		customerMap.put(id, object);
		return customerMap;
	}


	private static Map<Integer, Map<Long, AccountDetails>> addAccount(int id,long accNo,AccountDetails obj)
	{
		Map<Long, AccountDetails> getExisting = accountMap.get(id);
		
		if (getExisting == null)
		{
			getExisting = new HashMap<>();
			
			accountMap.put(id, getExisting);
		}
		
		getExisting.put(obj.getAccountNumber(), obj);
		
		return accountMap;
	}
	
	public Customer getCustomerInfo(int id) throws MistakeOccuredException 
	{
		
		HelperUtil.numberCheck(id);
		
		return customerMap.get(id);
	}

	
	public AccountDetails getAccountInfo(int cusId, long accNo)
			throws MistakeOccuredException 
	{
		HelperUtil.numberCheck(cusId);
		
		Map<Long, AccountDetails> map2 = accountMap.get(cusId);
		
		HelperUtil.objectCheck(map2, "CustomerId");
		
		AccountDetails accDetails = map2.get(accNo);
		
		HelperUtil.objectCheck(accDetails, "AccountDetails");
		
		return accDetails;
	}

	
}
