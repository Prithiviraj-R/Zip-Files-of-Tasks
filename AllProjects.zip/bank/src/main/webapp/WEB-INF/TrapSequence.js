function trapSequence(start,endLimit,secondNum)
{    
     const map=new Map();
     var end=endLimit;
     var secondNum=secondNum;
     var char=0;
     var date=0;
     while(start<=endLimit)
     {
         if((start%secondNum)===0 || (secondNum%start)===0)
         {
              map.set(start,secondNum);
              if(Math.floor(start/10)!=0)
              {
              char=start;
              date=start;
              var ans=0;
              while(date/10>=1)
              {
                 digit=date%10;
                 ans=ans+digit;
                 date=Math.trunc(Math.trunc(date/10));
              }
              if((ans%secondNum)===0 || (secondNum%ans)===0)
                 {
                   map.set(start,secondNum);
                 }
              }
              start=start+1;
              secondNum=secondNum+2;
         }
         else
         {
           if(secondNum==3)
           {
             start=start+1;
             secondNum=secondNum;
           }
           else
           {
             start=start+1;
             secondNum=secondNum-1;
           }  
        }
     }
     for(var answer of map)
     {
        document.getElementById("result").innerHTML+="<ul><li>"+answer+"</li></ul>";
     }``
     
     document.getElementById("count").innerHTML+="The Number of pairs is:"+map.size+"<br>";
}