package com.practice;

import java.util.Arrays;

public class matrix 
{
	public static void main(String[] args)
	{
		int[][] arr=new int[3][3];
		arr[0][0]=33;
		arr[0][1]=33;
		arr[0][2]=33;
		arr[1][0]=33;
		arr[1][1]=33;
		arr[1][2]=33;
		arr[2][0]=33;
		arr[2][1]=33;
		arr[2][2]=33;
		int[][] ansArr=new int[3][3];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				if(i==0 || j==0)
				{
					ansArr[i][j]=arr[i][j]*2;
				}
				else if(i==arr.length-1 || j==arr.length-1)
				{
					ansArr[i][j]=arr[i][j]*2;
				}
				else
				{
					ansArr[i][j]=arr[i][j]/2;
				}
			}
		}
		System.out.println(Arrays.deepToString(ansArr));
	}
}
