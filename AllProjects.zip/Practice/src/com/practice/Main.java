package com.practice;

public class Main
{

public static void main(String[] args)
  {
	   Main obj=new Main();
	   obj.show();
	   obj.speak();
  }


public void show() 
{
	
System.out.println("Hi i am bird.");	
	
}


public void speak() {
	
}





}
