package com.practice;

public class MaximumChar
{
	public static void main(String[] args) {
		System.out.println(maxChars("ThisisStri"));
	}
	public static int maxChars(String s)
    {
        //code here
        int length=s.length();
        int res=0;
        for(int i=0;i<length;i++)
        {
            res=Math.max(res,s.lastIndexOf(s.charAt(i))-i); 
        }
        return res-1;
    }
}
