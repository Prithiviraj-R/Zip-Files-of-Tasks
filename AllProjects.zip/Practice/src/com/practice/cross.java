package com.practice;

import java.util.Arrays;
import java.util.Scanner;

public class cross
{
	public static void main(String[] args)
	{
		int a[]= {0,35};
		int ag=9;
		int b=5;
		ag=76;
		a[0]=25;
		a[0]=5;
		System.out.println(Arrays.toString(a));
		System.out.println(ag+b);
		crossPattern("INDIAN");
		Scanner input=new Scanner(System.in);
	
		do {
			System.out.println("chak de india");
			System.out.println("Do you want to continue?");
			String check=input.nextLine();
			if(check.contains("n"))
			{
				break;
			}
		}
		while(true);
	}
	static void crossPattern(String S){
        // code here
        int length=S.length();
    
    for(int i=0;i<length;i++)
    {
        for(int j=0;j<length;j++)
        {
            if(i==j)
            {
                System.out.print(S.charAt(i));
            }
            else if(i+j==length-1)
            {
            	System.out.print(S.charAt(j));
            }
            else
            {
                System.out.print(" ");
            }
        }
        System.out.println();
    }
    }
}
