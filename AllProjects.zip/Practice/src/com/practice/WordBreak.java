package com.practice;

import java.util.ArrayList;
import java.util.List;

public class WordBreak
{
	public static void main(String[] args) {
		String A="ilikesamsung";
		String dictionary[]={ "i", "like", "sam",
				"sung", "samsung", "mobile",
				"ice","cream", "icecream", 
				"man", "go", "mango" };
		ArrayList<String> B=new ArrayList<>();
		for(String temp:dictionary)
		{
			B.add(temp);
		}
		System.out.println(wordBreak(A,B));
		
}
	public static int wordBreak(String A, ArrayList<String> B )
	{
		if(A.length()==0)
        {
            return 1;
        }
		
		
        for(int i=0;i<A.length();i++)
        {
               System.out.println(i);
		if(B.contains(A.substring(0,i)) && wordBreak(A.substring(i),B)==1)
		{

			return 1;
		}
		
        }
        
		return 0;
	}
	
}
