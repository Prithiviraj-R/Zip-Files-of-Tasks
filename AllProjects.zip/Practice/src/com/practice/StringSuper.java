package com.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StringSuper
{
	public static void main(String[] args)
	{
		String ques="i,like,this program very much";
		char[] jack=ques.toCharArray();
		List charList=Arrays.asList(jack);
		List mainList=new ArrayList();
		mainList.add(charList);
		System.out.println(Arrays.toString(jack));
		int i=0;
		int j=mainList.size()-1;
		while(i<=j)
		{
			if((char)mainList.get(i)==',')
			{
				jack[i]=' ';
				i++;
			}
			else if((char)mainList.get(j)==' ')
			{
				jack[j]=',';
				j--;
			}
			System.out.println(Arrays.toString(jack));
		}
		System.out.println(Arrays.toString(jack));
	}
}
