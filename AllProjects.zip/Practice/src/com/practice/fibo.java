package com.practice;
import util.HelperUtil;
public class fibo
{
public static void main(String[] args) {
	System.out.println(fibo(4));
}
static int fibo(int n)
{
	if(n<2)
	{
		return n;
	}
	System.out.println(n);
	int t=fibo(n-2)+fibo(n-1);
	
	return t;
	
}
}
