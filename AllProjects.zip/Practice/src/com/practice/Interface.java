package com.practice;

import java.util.List;

interface abc
{
	int a=0;
	default void show()
	{
		System.out.println("Ruju is singing");
	}
}

interface xyz
{
	int a=0;
	void show();
	void speak();
}


