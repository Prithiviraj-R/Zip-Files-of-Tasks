package com.practice;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class ObjectOutputStreamDemo 
{
public static void main(String[] args) throws IOException, ClassNotFoundException {
	Customer obj=new Customer();
	obj.setName("Prithivi");
	obj.setDob("18101999");
	obj.setPhoneNumber(8190008306l);
	obj.setAddress("Sungagate");
	obj.setCustomerId(0);
	Map<Integer,Customer> cusMap=new HashMap<>();
	cusMap.put(obj.getCustomerId(),obj);
	AccountDetails accobj=new AccountDetails();
	accobj.setBranch("France");
	accobj.setBalance(0);
	accobj.setAccountNumber(2010l);
	accobj.setCustomerId(0);
	Map hash1=new HashMap();
	hash1.put(accobj.getAccountNumber(), accobj);
	Map<Integer,Map<Long,AccountDetails>>hash3=new HashMap();
	hash3.put(obj.getCustomerId(), hash1);
	Scanner input=new Scanner(System.in);
	int choice=input.nextInt();
	switch(choice)
	{
	case 1:
		try
		{
			customer(cusMap);
		}
		catch(Exception ex)
		{
			
		}
		break;
	case 2:
		try
		{
			account(hash3);
		}
		catch(Exception ex)
		{
			
		}
		break;
		
	 case 3:
		 try
		 {
			readFile();
		 }
		 catch(Exception ex)
			{
				
			}
		 break;
		 		 
	}
}

public static void customer(Map<Integer,Customer> obj)
{
	File file=new File("/home/inc4/file");
	try(FileOutputStream fos=new FileOutputStream(file,true);
			ObjectOutputStream oos=new ObjectOutputStream(fos))
	{
		oos.writeObject(obj);
	}
	catch(IOException ex)
	{
	ex.printStackTrace();	
	}
}

public static void account(Map<Integer,Map<Long,AccountDetails>> obj)
{
	File file=new File("/home/inc4/file");
	try(FileOutputStream fos=new FileOutputStream(file,true);
			ObjectOutputStream oos=new ObjectOutputStream(fos))
	{
		oos.writeObject(obj);
	}
	catch(IOException ex)
	{
	ex.printStackTrace();	
	}
}
public static void readFile()
{
	File file=new File("/home/inc4/file");
	try(FileInputStream fos1=new FileInputStream(file);
	ObjectInputStream oos1=new ObjectInputStream(fos1))
	{
		Map<Integer,Customer> ob1=(Map<Integer,Customer>) oos1.readObject();
		Map<Integer,Map<Long,AccountDetails>> ob2=(Map<Integer,Map<Long,AccountDetails>>) oos1.readObject();
		System.out.println(ob1);
		System.out.println(ob2);
	}
	catch(IOException ex)
	{
		ex.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}



}
