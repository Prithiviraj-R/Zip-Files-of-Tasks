package com.practice;

import java.util.*;

public class Recrsion
{
	public static void main(String[] args) 
	{
		System.out.println(removeChars("computer","cat"));
	}
	 public static List<String> find_permutation(String S) 
	    {
	        List<String> newOne=permutation("",S);
	        Collections.sort(newOne);
	        return newOne;
	    }
	    public static ArrayList<String> permutation(String p,String up)
	    {
	    ArrayList<String> list=new ArrayList();
	    if(up.isEmpty())
	    {
	        
	        list.add(p);
	        return list;
	    }
	   
	        ArrayList<String> input=new ArrayList();
	        for(int i=0;i<up.length();i++)
	        {
	        	System.out.print(i);
	        	System.out.println(p+up.charAt(i));
	            System.out.println(up.substring(0,i)+up.substring(i+1,up.length()));
	            System.out.println("____");
	            input.addAll(permutation(p+up.charAt(i),up.substring(0,i)+up.substring(i+1,up.length())));
	        }
	        return input;
	    }
	    static String removeChars(String string1, String string2){
	        // code here
	        String forRemove="";
	        String spd="";
	        if(string2.length()==3)
	        {
	            return forRemove;
	        }
	        
	        for(int i=0;i<string2.length();i++)
	        {
	            for(int k=0;k<string1.length();k++)
	            {
	                if(string2.charAt(i)==string1.charAt(k))
	                {
	                    forRemove=forRemove+string1.replace(String.valueOf(string1.charAt(k)),"");
	                    spd=removeChars(forRemove,string2);
	                    System.out.println(spd);
	                }
	            }
	        }
	        return spd;
	    }
}
