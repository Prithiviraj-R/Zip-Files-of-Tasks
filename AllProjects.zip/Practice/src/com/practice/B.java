package com.practice;

import java.util.Arrays;

public class B extends Main implements abc
{
   public static void main(String[] args)
   {
	     B obj=new B();
	     obj.show();
	     Arrays.asList(null);
	     }
}
