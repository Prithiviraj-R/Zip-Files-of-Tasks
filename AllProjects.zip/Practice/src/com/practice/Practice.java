package com.practice;

import java.io.File;
import java.io.*;
import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;
import java.util.Scanner;

public class Practice
{
	static Properties property1=new Properties();
	
public static void main(String[] args) throws IOException
{
	Scanner input=new Scanner(System.in);
	Customer obj=new Customer();
	obj.setName("Prithivi");
	obj.setPhoneNumber(8190008306l);
	obj.setAddress("Sungagate");
	obj.setDob("18101999");
	Customer obj1=new Customer();
	obj1.setName("Ruju");
	obj1.setDob("18101999");
	obj1.setAddress("Karur");
	obj1.setPhoneNumber(654654645l);
	Customer obj3=new Customer();
	obj3.setName("Vignesh");
	obj3.setDob("18101999");
	obj3.setAddress("Karur");
	obj3.setPhoneNumber(654654645l);
	boolean condition=true;
	while(condition)
	{
		int choice=input.nextInt();
	switch(choice)
	{
	case 1:
	try(FileWriter writer=new FileWriter("/home/inc4"+File.separator+"Cust",true))
			{
	
	Properties property2=new Properties();
	property2.put(1,obj );
	property2.put(2,obj1);
	property1.put(String.valueOf(1), String.valueOf(property2));
	String obj2=property1.getProperty("1");
	System.out.println("After getting from property1:"+obj2);
    String[] splited=obj2.split("=");
    System.out.println(Arrays.toString(splited));
    String[] removed=new String[splited.length+1];
    for(int i=0;i<splited.length;i++)
    {
    	if(splited[i].charAt(0)=='{')
    	{
    		removed[i]=splited[i].replace("{", "");
    	}
    	else if(splited[i].charAt(splited[i].length()-1)=='}')
    	{
    		removed[i]=splited[i].replace("}", "");
    	}
    	else
    	{
    		removed[i]=splited[i];
    	}
    }
    System.out.println(Arrays.toString(removed));
    System.out.println("Enter the Size of Removed:"+removed.length);
	Properties property5=new Properties();
	for(int i=0;i<removed.length;i++)
	{
		if(i%2!=0)
		{
			property5.setProperty(String.valueOf(removed[i-1]),String.valueOf(removed[i]));
		}
	}
//	property5.setProperty(removed[0],removed[1]);
//	property5.setProperty(removed[2],removed[3]);
	property5.setProperty(String.valueOf(3),String.valueOf(obj3));
	System.out.println(property5);
	property1.setProperty("1",String.valueOf(property5));
	property5.store(writer,"");
			}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	break;
	case 2:
		try(FileReader reader=new FileReader("/home/inc4"+File.separator+"Cust"))
		{	
			Properties property3=new Properties();
			property3.load(reader);
			System.out.println("Property after loaded from file:"+property3);
			String result=property3.getProperty("1");
			System.out.println("After getting value of customerId:"+result);
			String arr[]=result.split("=");
			System.out.println("Array after Spliting'='"+Arrays.toString(arr));
			System.out.println("arr[0]:"+arr[0]);
			System.out.println("arr[1]:"+arr[1]);
			Properties property4=new Properties();
			property4.setProperty(arr[0],arr[1]);
			String result2=property4.getProperty(arr[0]);
		    String[] arr2=result2.split(",");
		    System.out.println("Array of PojoClass(Customer):"+Arrays.toString(arr2));
		}
		break;
	}
	}
}
}
