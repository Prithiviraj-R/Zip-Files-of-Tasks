package util;
import newexception.MistakeOccuredException;
public class HelperUtil
{
public static void indexCheck(int startingNumber,int endingNumber)throws MistakeOccuredException
{
    if(startingNumber>endingNumber)
    {
       throw new MistakeOccuredException("Starting number should not exceed Ending Number");
    }
}

public static void stringCheck(String testString)throws MistakeOccuredException
{
    if(testString==null || testString.isEmpty())
    {
      throw new MistakeOccuredException("String cannot be null or Empty");
    }
}

public static void stringCheck(String testString,String message)throws MistakeOccuredException
{
    if(testString==null || testString.isEmpty())
    {
      throw new MistakeOccuredException(message);
    }
}

public static void objectCheck(Object objectName)throws MistakeOccuredException
{
    if(objectName==null)
    {
        throw new MistakeOccuredException("Object Should not be null");
    }
}

public static void objectCheck(Object objectName,String objType)throws MistakeOccuredException
{
    if(objectName==null)
    {
        throw new MistakeOccuredException(objType);
    }
}


public static void checkingStringArray(String[] stringArray)throws MistakeOccuredException
{
    for(String words:stringArray)
    {
      stringCheck(words);
    } 
}

public static void numberCheck(int num)throws MistakeOccuredException
{
   if(num<0)
   {
      throw new MistakeOccuredException("Number should Not be Negative or Zero.");
   }
}
}
