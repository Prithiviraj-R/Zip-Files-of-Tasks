package newexception;
public class MistakeOccuredException extends Exception
{
public MistakeOccuredException(String message)
{
  super(message);
}
public MistakeOccuredException(Exception message)
{
  super(message);
}
}
