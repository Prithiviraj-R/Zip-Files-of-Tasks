function statusSpace()
{
    var body=document.body;
    var div1= document.createElement("div");
    div1.setAttribute("id","status");
    div1.style.border="1px solid black";
    div1.style.height="600px";
    div1.style.width="1100px";
    var url=document.getElementById("url").value;
    var frame=document.createElement("iframe");
    frame.src=url;
    frame.style.height="500px";
    frame.style.width="1000px";
    div1.appendChild(frame);
    body.appendChild(div1);
    $().ready
}